import fs from "fs";
import path from "path";

const group = async (ctx, event, eventType) => {
    try {
        if (!event?.participants) return null;

        const participants = event.participants.filter(p => p?.phoneNumber).map(p => p.phoneNumber);
        const author = event.author;
        let txt;

        // جلب عدد أعضاء المجموعة الحالي
        let memberCount = 0;
        let username = 'unknown';
        
        try {
            const groupMetadata = await ctx.sock.groupMetadata(event.chat);
            memberCount = groupMetadata.participants.length;
        } catch (err) {
            console.error("خطأ في جلب عدد الأعضاء:", err);
            memberCount = participants.length;
        }

        // استخراج اسم العضو الأول (للعرض في الزخرفة)
        if (participants.length > 0) {
            username = participants[0].split('@')[0];
        }

        const users = participants.length 
            ? participants.map(p => '@' + p.split('@')[0]).join(' and ') 
            : 'No users';
        const authorTag = author ? '@' + author.split('@')[0] : 'Unknown';

        // الزخرفة الجديدة للترحيب والوداع
        const welcomeMsg = `
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
❒ *╭┈⊰* 🌷الــتــرحــيــب🌷 *⊰┈ ✦*
*┊˹📯˼┊ اهــلا بـك/ي*
┊˹🥷🏻˼┊ @${username}
┊👥 عدد الأعضاء الآن: *${memberCount}*
┊📩 *اقرأ وصف المجموعة*

> *منور الجروب ┊˹✅˼┊*
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
>  𝐑𝐄𝐌ｼ 𝐁𝐎𝐓 🪶`;

        const goodbyeMsg = `
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
❒ *╭┈⊰* 🌷الــوداع🌷 *⊰┈ ✦*
*┊˹📯˼┊ مع السلامة*
┊˹🥷🏻˼┊ @${username}
┊👥 عدد الأعضاء الآن: *${memberCount}*
┊📩 *نتمنى رؤيتك مرة أخرى*

> *وداعاً ┊˹👋˼┊*
*❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜*
>  𝐑𝐄𝐌ｼ 𝐁𝐎𝐓 🪶`;

        const messages = {
            add: welcomeMsg,
            remove: goodbyeMsg,
            promote: `《🪻》${users} تمت ترقيته 👏🐤\n\n> ✧ تم التغيير بواسطة:\n> » ${authorTag}`,
            demote: `《🪻》${users} تم خفضه من الإدارة 🐦\n\n> ✧ تم التغيير بواسطة:\n> » ${authorTag}`
        };

        txt = messages[eventType];
        if (!txt) return null;
        
        if (global.db.groups[event.chat]?.noWelcome === true) return 9999;

        const img = ["remove", "add"].includes(eventType) 
            ? (event.userUrl || "https://files.catbox.moe/hm9iq4.jpg") 
            : "https://files.catbox.moe/hm9iq4.jpg";

        await ctx.sock.msgUrl(event.chat, txt, {
            img,
            title: ctx.config?.info.nameBot || "WhatsApp Bot",
            body: "BY : 𝐁𝟕𝐑ｼ",
            mentions: author ? [author, ...participants] : participants,
            newsletter: {
                name: '◜𝐑𝐄𝐌┊🎈┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
                jid: '120363158797567045@newsletter'
            },
            big: ["remove", "add"].includes(eventType)
        });

    } catch (e) {
        console.error(e);
    }
    return null;
};

const access = async (msg, checkType, time) => {
    const conn = await msg.client();
    
    const quoted = {
        key: {
            participant: `${msg.sender.split('@')[0]}@s.whatsapp.net`,
            remoteJid: 'status@broadcast',
            fromMe: false,
        },
        message: {
            contactMessage: {
                displayName: `${msg.pushName}`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${msg.pushName}\nitem1.TEL;waid=${msg.sender.split('@')[0]}:${msg.sender.split('@')[0]}\nEND:VCARD`,
            },
        },
        participant: '0@s.whatsapp.net',
    };
    
    const messages = {
        cooldown: `*♡⏳ استنى ${time || 'بعض كام ثانيه'} ثانية وكمل الأمر ⏳♡*\n⊱⋅ ──────────── ⋅⊰\n> *_لازم تصبر شويه عشان الأمر ده مينفعش فيه الاسبام_*`,
        owner: `*♡ 🇩🇪 الأمر ده لـ المطورين فقط 🇩🇪♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر ده لـ المطورين البوت لازم تكون مطور عشان تقدر تستخدمه_`,
        group: `*♡💠 الأمر ده بيشتغل بس ف الجروبات 💠♡*\n⊱⋅ ──────────── ⋅⊰\n> *_لازم الأمر ده تستخدمه ف جروب فقط ممنوع غير كده_*`,
        admin: `*♡📯 الأمر ده لـ الادمن فقط 📯♡*\n⊱⋅ ──────────── ⋅⊰\n> *_انت مجرد عضو لازم تبقي ادمن يا عضو يا عبد_*`,
        private: `*♡🏷️ الأمر ده في الخاص فقط 🏷️♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر ف الخاص بس ياحبيبي_*`,
        botAdmin: `*♡📌 لازم اكون ادمن عشان انقذ الأمر 📌♡*\n⊱⋅ ──────────── ⋅⊰\n> *_حطني ادمن عشان تقدر تستعمل الأمر ده_*`,
        noSub: `*♡🫒 الأمر ده ف البوت الأساسي فقط 🫒♡*\n⊱⋅ ──────────── ⋅⊰\n> *_ادخل الجروب ده و جرب الأمر [ https://chat.whatsapp.com/Epfd9J7t8tR6nnpIDjtGQZ?mode=gi_t ] ياريت من غير سبام_*`,
        disabled: `*♡🗃️ الامر متوقف (تحت صيانة) 🗃️♡*\n⊱⋅ ──────────── ⋅⊰\n> *_الامر تحت صيانه قريباً بيشتغل تاني_*`,
        error: `*♡❌ الأمر فيه خطأ، كلم المطورين ❌♡*\n⊱⋅ ──────────── ⋅⊰\n*_اكتب " .المطور " عشان يبعتلك رقم المطور_*`
    };
    
    if (conn && messages[checkType]) {
        await conn.msgUrl(msg.chat, messages[checkType], {
            img: "https://i.pinimg.com/originals/02/c3/51/02c351dfd4eb72a62f225ce964dc510d.jpg",
            title: "𝐀𝐥𝐞𝐫𝐭𝐬 | 𝐖𝐚𝐫𝐧𝐢𝐧𝐠𝐬",
            body: "𝐵𝑜𝑡 𝑎𝑙𝑒𝑟𝑡𝑠: 𝑅𝑒𝑎𝑑 𝑡𝒉𝑒 𝑚𝑒𝑠𝑠𝑎𝑔𝑒 𝑡𝑜 𝑙𝑒𝑎𝑟𝑛 𝑚𝑜𝑟𝑒",
            newsletter: {
                name: '𝐕𝐈𝐈7 ~ 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 🕷️',
                jid: '120363225356834044@newsletter'
            },
            big: false
        }, quoted);
        return false;  
    }
    return null;  
};

export { access, group };