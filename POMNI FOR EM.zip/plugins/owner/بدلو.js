// plugins/badl.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let handler = async (m, { text, command, usedPrefix }) => {
    const allowedNumber = ['201207384435@s.whatsapp.net', '201116880068@s.whatsapp.net'];
    if (!allowedNumber.includes(m.sender)) {
        return m.reply('❌ هذا الأمر غير مسموح لك.');
    }

    if (!text || !text.includes('|')) {
        return m.reply(`❌ الصيغة خطأ.\nاستعمل: ${usedPrefix + command} الكلمة القديمة|الكلمة الجديدة`);
    }

    const [oldText, newText] = text.split('|').map(s => s.trim());
    if (!oldText || !newText) {
        return m.reply('❌ تأكد أنك كتبت الكلمتين بشكل صحيح مفصولتين بـ |');
    }

    const pluginsDir = path.join(__dirname, '../plugins');
    let changedFiles = [];

    try {
        const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
        for (let file of files) {
            const filePath = path.join(pluginsDir, file);
            let content = fs.readFileSync(filePath, 'utf8');
            if (content.includes(oldText)) {
                const updatedContent = content.split(oldText).join(newText);
                fs.writeFileSync(filePath, updatedContent, 'utf8');
                changedFiles.push(file);
                console.log(`✅ تم التبديل في: ${file}`);
            }
        }

        if (changedFiles.length === 0) {
            await m.reply(`ℹ️ لم يتم العثور على "${oldText}" في أي ملف.`);
        } else {
            await m.reply(`✅ تم التبديل في الملفات:\n${changedFiles.join('\n')}`);
        }
    } catch (err) {
        console.error('❌ خطأ أثناء التبديل:', err);
        await m.reply('❌ حدث خطأ أثناء التبديل.');
    }
};

handler.usage = ['بدل النص القديم|النص الجديد'];
handler.category = 'owner';
handler.command = /^(بدلو|بدل)$/i;
handler.owner = true;

export default handler;