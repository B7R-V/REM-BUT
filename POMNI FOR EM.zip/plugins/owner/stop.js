const test = async (m, { conn, bot }) => {
  m.react("🟢")
  
  conn.msgUrl(m.chat, "🇨🇱", { 
    title: "𝐑𝐄𝐌 ✰ 𝐁𝐎𝐓",
    body: "BY : 𝐁𝟕𝐑ｼ",
    img: "https://g.top4top.io/p_3700yob0b1.jpg",
    big: false 
  });
  
  setTimeout(() => {
    bot.stop();
  }, 1000); 
};

test.category = "owner";
test.command = ["ايقاف", "stop"];
test.owner = true;
export default test;