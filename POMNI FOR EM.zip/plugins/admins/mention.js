const handler = async (m, { conn }) => {
    const metadata = await conn.groupMetadata(m.chat);
    const participants = metadata.participants;

    const time = new Date().toLocaleTimeString('ar-EG');
    const date = new Date().toLocaleDateString('ar-EG');

    let messageText = `*◞👥‟⌝╎مـنـشـن جـمـاعـي*\n`;
    messageText += `*~⊱⊹•─๋︩︪╾─•┈⧽ 🎀 ⧼┈•─╼─๋︩︪•⊹⊰~*\n\n`;

    messageText += `> *╭*\n`;
    messageText += participants
        .map(mem => `> ┊  @${mem.id.split('@')[0]}`)
        .join('\n');
    messageText += `\n> *╰*\n\n`;

    messageText += `*⌝🕒╎الـوقـت:* ${time}\n`;
    messageText += `*⌝📅╎التـاريـخ:* ${date}\n\n`;

    messageText += `*~⊱⊹•─๋︩︪╾─•┈⧽ 🎀 ⧼┈•─╼─๋︩︪•⊹⊰~*\n`;
    messageText += `> 𝒃𝒚 : 𝒓𝒆𝒎 • 𝒃𝒐𝒕`;

    return conn.sendMessage(m.chat, {
        text: messageText,
        mentions: participants.map(p => p.id)
    });
};

handler.command = ['منشن'];
handler.admin = true;

export default handler;