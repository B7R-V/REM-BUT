let handler = async (m, {
    conn,
    bot
}) => {
const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363158797567045@newsletter',
        newsletterName: '◜𝐑𝐄𝐌┊🎈┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "𝐑𝐄𝐌 ✰ 𝐁𝐎𝐓",
        body: "BY : 𝐁𝟕𝐑ｼ",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});
const { images } = bot.config.info;
const img = images.random()
await conn.sendMessage(m.chat, { 
  text: `
GitHub: _*https://github.com/deveni0/Pomni-AI/tree/main*_
> *لا تنسي وضع نجمة لـ الريبو 🌟*
`,
  contextInfo: context(m.sender, img)
}, { quoted: reply_status });
}
handler.usage = ["سكريبت"];
handler.category = "group";
handler.command = ["سكريبت", "سورس", "sc"];

export default handler;