// plugins/menu.js
import { generateWAMessageFromContent, prepareWAMessageMedia } from '@whiskeysockets/baileys';

const MENU_TIMEOUT = 120000;

const CATEGORIES = [
  [1, 'التـحـمـيـل', 'downloads', '📂'],
  [2, 'الـمـجـمـوعـات', 'group', '🐞'],
  [3, 'الـمـلـصـقـات', 'sticker', '🌄'],
  [4, 'الـمـطـوريـن', 'owner', '🇩🇪'],
  [5, 'امـثـلـه', 'example', '✳️'],
  [6, 'الـادوات', 'tools', '🚀'],
  [7, 'الـبـحـث', 'search', '🌐'],
  [8, 'الادمــن', 'admin', '👨🏻‍⚖️'],
  [9, 'الالــعـاب', 'games', '🎮'],
  [10, 'الچيف', 'gif', '✴️'],
  [11, 'الـبــنـك', 'bank', '💰'],
  [12, 'الـذكـاء الاصـطـنـاعـي', 'ai', '🤖'],
  [13, 'الـبـوتـات الـفـرعـي', 'sub', '♥️'],
  [14, 'أخــرى', 'other', '🌹']
];

const getCat = n => CATEGORIES.find(c => c[0] === n);

if (!global.menus) global.menus = {};

const clean = () => {
  const now = Date.now();
  Object.keys(global.menus).forEach(k => {
    if (now - global.menus[k].time > MENU_TIMEOUT) delete global.menus[k];
  });
};

const getImg = (bot) => {
  const { images } = bot.config.info;
  return Array.isArray(images) ? images[Math.floor(Math.random() * images.length)] : images;
};

const context = (jid, img) => ({
  mentionedJid: [jid],
  isForwarded: true,
  forwardingScore: 1,
  forwardedNewsletterMessageInfo: {
    newsletterJid: '120363158797567045@newsletter',
    newsletterName: '◜𝐑𝐄𝐌┊𖤐┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
    serverMessageId: 0
  },
  externalAdReply: {
    title: "𝐑𝐄𝐌 ✰ 𝐁𝐎𝐓",
    body: "BY : 𝐁𝟕𝐑ｼ",
    thumbnailUrl: img,
    sourceUrl: '',
    mediaType: 1,
    renderLargerThumbnail: true
  }
});

const menu = async (m, { conn, bot }) => {
  clean();

  // تجميع الأوامر
  const cmds = await bot.getAllCommands();
  const cats = {};
  cmds.forEach(c => {
    if (!c.usage?.length) return;
    const cat = c.category || 'other';
    if (!cats[cat]) cats[cat] = [];
    cats[cat].push(c);
  });

  // بناء الأقسام (sections) للأزرار
  const sections = CATEGORIES.map(cat => ({
    title: `▸ ${cat[1]} ${cat[3]}`,
    rows: [
      {
        header: `📌 القسم ${cat[0]}`,
        title: `${cat[1]} ${cat[3]}`,
        description: `اضغط لعرض أوامر ${cat[1]}`,
        id: `${cat[0]}`  // رقم القسم
      }
    ]
  }));

  // الأزرار المطلوبة فقط:
  const buttons = [
    {
      name: "single_select",
      buttonParamsJson: JSON.stringify({
        title: "「 📂 أقسام البوت 」",
        sections: sections
      })
    },
    {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "📢 قناة المطور",
        url: "https://whatsapp.com/channel/0029Va8Y2DcLY6dENF4Jry0u"
      })
    },
    {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: "⚙️ تنصيب البوت",
        id: ".تتصيب"
      })
    }
  ];

  // تحضير الصورة
  let mediaMessage = null;
  const imgUrl = getImg(bot);
  if (imgUrl) {
    mediaMessage = await prepareWAMessageMedia(
      { image: { url: imgUrl } },
      { upload: conn.waUploadToServer }
    );
  }

  // بناء الرسالة التفاعلية
  const interactiveMessage = {
    header: mediaMessage ? { hasMediaAttachment: true, ...mediaMessage } : undefined,
    body: { text: "┏━━━━━━━┫ 🍁 ┣━━━━━━━┓\n┃ اختر القسم من القائمة أدناه\n┗━━━━━━━┫ 🖤 ┣━━━━━━━┛" },
    footer: { text: "𝐑𝐄𝐌 ✰ 𝐁𝐎𝐓" },
    contextInfo: context(m.sender, imgUrl),
    nativeFlowMessage: {
      buttons: buttons,
      messageParamsJson: JSON.stringify({
        bottom_sheet: {
          in_thread_buttons_limit: 1,
          divider_indices: [1, 2, 3, 4, 5, 6, 7, 8, 9, 999],
          list_title: "📂 قائمة أقسام البوت",
          button_title: "『🎶┃القوائـ🗒️ـم┃🎶』"
        },
        tap_target_configuration: {
          description: "قائمة البوت",
          canonical_url: "https://example.com",
          domain: "example.com",
          button_index: 0
        }
      })
    }
  };

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage
        }
      }
    },
    { userJid: conn.user.jid, quoted: m }
  );

  await conn.sendMessage(m.chat, { react: { text: '📋', key: m.key } });
  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  // تخزين القائمة في global.menus
  global.menus[msg.key.id] = { cats, chatId: m.chat, time: Date.now() };
};

// معالج الضغط على الأزرار
menu.before = async (m, { conn, bot }) => {
  clean();

  const menuData = global.menus[m.quoted?.id];
  if (!menuData) return false;

  const catNumber = parseInt(m.text);
  const cat = getCat(catNumber);

  if (cat) {
    const cmds = menuData.cats[cat[2]];
    if (!cmds?.length) {
      await conn.sendMessage(m.chat, { text: '*❌≥ القسم فاضي*' }, { quoted: m });
      return true;
    }

    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.quoted.id, fromMe: true } });
    delete global.menus[m.quoted.id];

    const cmdsList = cmds.map(c => `┃ ${cat[3]} .${c.usage.join(`\n┃ ${cat[3]} . `)}`).join('\n');
    const txt = `
┏━━━━━━━┫ 📍 ┣━━━━━━━┓
┃ ⌯︙ قـسـم ${cat[1]} ${cat[3]}
${cmdsList}
┗━━━━━━━┫ 🍁 ┣━━━━━━━┛`.trim();

    await conn.sendMessage(m.chat, { text: txt, contextInfo: context(m.sender, getImg(bot)) }, { quoted: m });
    return true;
  }

  // إذا لم يكن زر قسم (مثل زر التنصيب أو قناة المطور)، نسمح بمروره للمعالجات الأخرى
  return false;
};

menu.command = ['الاوامر', 'القائمة', 'menu', 'اوامر'];
export default menu;