const handler = async (m, { conn, text }) => {
    if (!text) return m.reply("⟦❗⟧ اكتب نص الفيديو او الاغنيه");
    
    const res = await fetch(`https://emam-api.web.id/home/sections/Search/api/YouTube/search?q=${text}`);
    const { data } = await res.json();
    const { title, image, timestamp: time, url } = data[0];

    await conn.sendButton(m.chat, {
        imageUrl: image,
        bodyText: `${title} ╎ ${time}`,
        footerText: "𝗬𝗼𝘂𝗧𝘂𝗯𝗲 • 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱",
        buttons: [
            { name: "quick_reply", params: { display_text: "🎼 𖤐 تـحـمـيـل صـوت", id: `.يوت_اغنيه ${url}` } },
            { name: "quick_reply", params: { display_text: "🎬 𖤐 تـحـمـيـل فـيـديـو", id: `.يوتيوب ${url}` } }
        ],
        mentions: [m.sender],
        newsletter: { name: "◜𝐑𝐄𝐌┊😔┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞", jid: "120363158797567045@newsletter" },
        interactiveConfig: { buttons_limits: 10, list_title: "", button_title: "", canonical_url: url }
    }, m);
};

handler.usage = ["فيديو", "اغنيه", "شغل"];
handler.category = "downloads";
handler.command = ["اغنيه", "فيديو", "اغنية", "play", "video"];

export default handler;