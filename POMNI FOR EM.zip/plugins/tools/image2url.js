import fs from 'fs';
import axios from 'axios';
import FormData from 'form-data';
import { uploadToCatbox } from "../../system/utils.js";

const handler = async (m, { conn, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  if (!mime) throw '*⟦ 📍 ⟧ اعمل ريبلاي علي الصوره او الفيديو أو الصوت*';
  
  const media = await q.download();
  const link = await uploadToCatbox(media);
  
  await conn.sendButton(m.chat, {
    imageUrl: link,
    bodyText: "🗃️ ~ Successful *(catbox.moe)*\n- ```" + link + "```",
    footerText: "AZZKIF | UNKNOWN",
    buttons: [
      { name: "cta_copy", params: { display_text: "Copy Link", copy_code: link } },
    ],
    mentions: [m.sender],
    newsletter: {
      name: '◜𝐑𝐄𝐌┊🎈┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞',
      jid: '120363158797567045@newsletter'
    },
    interactiveConfig: {
      buttons_limits: 10,
      list_title: "◜𝐑𝐄𝐌┊🍦┊𝐂𝐇𝐀𝐍𝐍𝐄𝐋◞",
      button_title: "Click Here",
      canonical_url: "info-dev-b7r.verce.app"
    }
  }, m);
};

handler.usage = ["لرابط"];
handler.category = "tools";
handler.command = ['رابط', 'image2url'];

export default handler;